import React from 'react'

const Footer = () => {
  return (
    <>
      <footer className='w-100 bg-light text-center m-3  footer'>
        <p className='p-2'>copyright @ 2022 wahab technical.All rights are reserved</p>
      </footer>
    </>
  )
}

export default Footer
